package com.joshua.traderDatabaseJdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraderDatabaseJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
